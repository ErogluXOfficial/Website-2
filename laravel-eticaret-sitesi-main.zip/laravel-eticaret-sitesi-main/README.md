# LARAVEL İLE TEKNOLOJİK ÜRÜNLER SATIŞ SİTESİ | E-TİCARET SİTESİ
Web sitesinin barındırdığı hizmetler;

- Dinamik bir sayfa yapısı. Ana sayfa kısmında değiştirilebilir süresi ayarlanabilir indirimli ürünler kısmı; Admin panelinden düzenlenebilir, yeni ürünler eklenebilir ve indirimin süresi belirlenebilir. Kategorize edilmiş son eklenen ve en çok ziyaret edilen ürünler kısmı. 
- Alışveriş kısmında kategoriye göre ürün arama, fiyat sınırlandırması yapma, isme göre veya fiyata göre artan-azalan sıralama işlemleri. 
- Ürün favorileme ve sepete atıp sipariş verme.
- Site içerisinde kullanıcılar için mail yoluyla şifre sıfırlama sistemi.
- Hava durumu ve döviz web api leri.
- Ürün reklamları için ana sayfada bulunan bağlantılı slider.

#ADMİN PANELİ İŞLEMLERİ
- Veriler; günlük satılan ürün adedi, kazanç gibi verilerin bulunduğu sayfayı içerir.
- Kategoriler; alışveriş sayfasında bulunan kategoriler kısmını düzenlemeyi sağlar, yeni kategori ekleme ve kategori düzenleme işlemleri.
- Tüm ürünler; ürün ekleme, düzenleme, silme işlemleri gerçekleştirilir.
- Ana sayfa slider; ana sayfadaki slider kısmını düzenlemeyi sağlar.
- İndirim ürünleri; ana sayfadaki indirimli ürünlerin süre ayarını yapmayı sağlar.
- Tüm siparişler; bütün siparişleri gösterir, sipariş detayı, sipariş durumu iptal ve kabul etmeyi sağlar.

#KULLANICI PANELİ İŞLEMLERİ
- Profilim; profil bilgilerini güncellemeyi, profil fotoğrafı yüklemeyi sağlar.
- Siparişlerim; siparişleri görmeyi, iptal etme seçeneklerini sunar.
- Şifre değiştir; şifre değiştirmeyi sağlar.
- Favoriler; önceden favorilenmiş ürünlerin bulunduğu kısımdır.

Detaylı bilgi ve ekran görüntüleri için [**Rapor.pdf**](https://github.com/omerayilmazdir/laravel-eticaret-sitesi/blob/main/Rapor.pdf) dosyasını okuyunuz.
