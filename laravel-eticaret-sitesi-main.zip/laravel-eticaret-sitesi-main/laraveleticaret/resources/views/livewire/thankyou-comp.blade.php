<div>
    <main id="main" class="main-site">
        <div class="container">
            <div class="wrap-breadcrumb">
                <ul>
                    <li class="item-link"><a href="/" class="link">anasayfa</a></li>
                    <li class="item-link"><span>Teşekkürler</span></li>
                </ul>
            </div>
        </div>
        <div class="container pb-60">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2>Alışverişlerinizde bizi tercih ettiğiniz için teşekkür ederiz.</h2>
                    <p>Onay e postası gönderildi.</p>
                    <a href="/shop" class="btn btn-submit btn-submitx">Alışverişe devam et</a>
                </div>
            </div>
        </div>
    </main>
</div>
